var searchData=
[
  ['value',['value',['../class_reg_generator.html#ad557c58539b7d84e7667d0259d739000',1,'RegGenerator']]],
  ['valuegenerator',['ValueGenerator',['../class_value_generator.html',1,'ValueGenerator'],['../class_value_generator.html#a537f79ef495f29177ead85663747b249',1,'ValueGenerator::ValueGenerator(QObject *parent=nullptr)'],['../class_value_generator.html#aadc21f6d0fea326294742d8e28cf5816',1,'ValueGenerator::ValueGenerator(QString rvf, double zeroShift, QString dinamicSystemError, RandomDistributionType disrType, QVector&lt; double &gt; distrParams)']]],
  ['valuegenerator_2ecpp',['valuegenerator.cpp',['../valuegenerator_8cpp.html',1,'']]],
  ['valuegenerator_2eh',['valuegenerator.h',['../valuegenerator_8h.html',1,'']]],
  ['valuepulse',['valuePulse',['../class_pulse_controller.html#a165006a68ef3b02f3b25ee393d373ca0',1,'PulseController']]],
  ['valuescontroller',['ValuesController',['../class_values_controller.html',1,'ValuesController'],['../class_values_controller.html#a79c5f5459d0fa9c0ae201f7af9a21f89',1,'ValuesController::ValuesController(QObject *parent=nullptr)'],['../class_values_controller.html#a9d8f277bbf71b14581286225e81d4c93',1,'ValuesController::ValuesController(ImitatorConfig *config)']]],
  ['valuescontroller_2ecpp',['valuescontroller.cpp',['../valuescontroller_8cpp.html',1,'']]],
  ['valuescontroller_2eh',['valuescontroller.h',['../valuescontroller_8h.html',1,'']]],
  ['valuesnumber',['valuesNumber',['../class_values_controller.html#abfd5066e990c480cd415979a208e6d91',1,'ValuesController']]],
  ['valuespublished',['valuesPublished',['../class_values_controller.html#ab8b868daf6749f35165d7f0ebf4ae35e',1,'ValuesController']]],
  ['valuetype',['valueType',['../class_reg_generator.html#aabe826a51b5b4917754f94264f601ea8',1,'RegGenerator::valueType()'],['../class_registr_config.html#a225f0855af5ecab5e7c2579a7e949117',1,'RegistrConfig::valueType()'],['../_random_types_8h.html#ad9971b6ef33e02ba2c75d19c1d2518a1',1,'ValueType():&#160;RandomTypes.h']]],
  ['variance',['Variance',['../_random_types_8h.html#ae108afd6d00a3eb3fe79cd02076d2149aaff9b7132f214f75dc24f775055355fa',1,'RandomTypes.h']]],
  ['version',['version',['../struct_journal_i_d.html#a9c3b1be1f5d693879f1aa98a83aa9e21',1,'JournalID']]]
];
