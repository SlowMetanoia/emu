var searchData=
[
  ['headerstring',['headerString',['../struct_journal_i_d.html#a5130c248f0573438dbcef7bcfa37b9f3',1,'JournalID']]]
];
