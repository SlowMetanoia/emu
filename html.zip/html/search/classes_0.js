var searchData=
[
  ['binmessage',['BinMessage',['../class_bin_message.html',1,'']]]
];
