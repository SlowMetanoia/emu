var searchData=
[
  ['journalid',['JournalID',['../struct_journal_i_d.html',1,'']]],
  ['journalwriter',['JournalWriter',['../class_journal_writer.html',1,'']]]
];
