var searchData=
[
  ['windowmanager',['WindowManager',['../class_window_manager.html',1,'']]]
];
