var searchData=
[
  ['journal',['Journal',['../_random_types_8h.html#ae8f073eec97d33cf9783ecbe50531dfdae5620da7bc6a4390b36a2d6bede3213e',1,'RandomTypes.h']]]
];
