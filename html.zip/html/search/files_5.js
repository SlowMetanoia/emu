var searchData=
[
  ['journalwriter_2ecpp',['journalwriter.cpp',['../journalwriter_8cpp.html',1,'']]],
  ['journalwriter_2eh',['journalwriter.h',['../journalwriter_8h.html',1,'']]]
];
