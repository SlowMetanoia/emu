var searchData=
[
  ['windowmanager_2ecpp',['windowmanager.cpp',['../windowmanager_8cpp.html',1,'']]],
  ['windowmanager_2eh',['windowmanager.h',['../windowmanager_8h.html',1,'']]]
];
