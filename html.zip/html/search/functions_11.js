var searchData=
[
  ['valuegenerator',['ValueGenerator',['../class_value_generator.html#a537f79ef495f29177ead85663747b249',1,'ValueGenerator::ValueGenerator(QObject *parent=nullptr)'],['../class_value_generator.html#aadc21f6d0fea326294742d8e28cf5816',1,'ValueGenerator::ValueGenerator(QString rvf, double zeroShift, QString dinamicSystemError, RandomDistributionType disrType, QVector&lt; double &gt; distrParams)']]],
  ['valuepulse',['valuePulse',['../class_pulse_controller.html#a165006a68ef3b02f3b25ee393d373ca0',1,'PulseController']]],
  ['valuescontroller',['ValuesController',['../class_values_controller.html#a79c5f5459d0fa9c0ae201f7af9a21f89',1,'ValuesController::ValuesController(QObject *parent=nullptr)'],['../class_values_controller.html#a9d8f277bbf71b14581286225e81d4c93',1,'ValuesController::ValuesController(ImitatorConfig *config)']]],
  ['valuespublished',['valuesPublished',['../class_values_controller.html#ab8b868daf6749f35165d7f0ebf4ae35e',1,'ValuesController']]]
];
