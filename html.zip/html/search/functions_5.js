var searchData=
[
  ['generalinit',['GeneralInit',['../class_initer.html#a088e4b7a4395c32a5bbe932c3db35054',1,'Initer']]],
  ['generatenamefromtime',['generateNameFromTime',['../class_journal_writer.html#a1762840b51e6631c7a6be80631e16e0e',1,'JournalWriter']]],
  ['generatenextvalues',['generateNextValues',['../class_series.html#a2274def40fd4c03eba80a8735b885dfb',1,'Series']]],
  ['generatevalue',['generateValue',['../class_value_generator.html#abb8134945ee903005e52934aae8fcbd2',1,'ValueGenerator']]],
  ['getcurrentvalues',['getCurrentValues',['../class_series.html#a2c20b127e35a3aac8207cecc270ead7e',1,'Series']]],
  ['getinstance',['getInstance',['../class_c_l_i_manager.html#a30fd449e0fea9cf14f56bf1ae17934ce',1,'CLIManager::getInstance()'],['../class_journal_writer.html#adc9e15e0d3114eba2658afc48c4c44a4',1,'JournalWriter::getInstance()'],['../class_out_manager.html#a25e2f6c90af51feae79e8233d9e746cd',1,'OutManager::getInstance()'],['../class_pulse_controller.html#ac7e6d3cb62727c89da948551d4cdce01',1,'PulseController::getInstance()'],['../class_pulse_generator.html#ace9e6e44b3fcd3103b65805d44261ced',1,'PulseGenerator::getInstance()'],['../class_socket_writer.html#a071c5c35fb17e082429eb9ebb1fcf5c9',1,'SocketWriter::getInstance()'],['../class_values_controller.html#a2b7b09d37db8c1cf82d35024254b5628',1,'ValuesController::getInstance()'],['../class_window_manager.html#a788e5991ead0a077b39dcd25f3116192',1,'WindowManager::getInstance()']]],
  ['getintance',['getIntance',['../class_configurator.html#a7138afa6d06c32b2e43495d108741c9f',1,'Configurator']]],
  ['getnewregistrform',['getNewRegistrForm',['../class_window_manager.html#a8f2e28f6011da17a58aa1f31f57508f0',1,'WindowManager']]],
  ['getpulsewaitms',['getPulseWaitMs',['../class_pulse_generator.html#a22da8e28f2e7621b1d87a92eaf527bba',1,'PulseGenerator']]],
  ['gotnewpulse',['gotNewPulse',['../class_pulse_controller.html#ada3a07fc7a533e76d0d91e2e8c31e75e',1,'PulseController']]]
];
