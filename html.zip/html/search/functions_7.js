var searchData=
[
  ['journalwriter',['JournalWriter',['../class_journal_writer.html#ae35ea91e1a2e0b87fdb45826bfde47b6',1,'JournalWriter']]]
];
