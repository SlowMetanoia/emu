var searchData=
[
  ['next',['next',['../class_series.html#a0c87433f79b7d3359d986e130225d469',1,'Series']]]
];
