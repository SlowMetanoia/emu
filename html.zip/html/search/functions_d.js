var searchData=
[
  ['randomerrorfunc',['randomErrorFunc',['../class_value_generator.html#a87e54f9bff53072f70c89cc1490dbd4e',1,'ValueGenerator']]],
  ['readconfig',['readConfig',['../class_configurator.html#a400f7c5c3362fcab86051b014e894544',1,'Configurator']]],
  ['reader',['Reader',['../class_reader.html#adcda31b507720ab44044d7a21686fba2',1,'Reader']]],
  ['reggenerator',['RegGenerator',['../class_reg_generator.html#af64142fffe52d51c318429c8c41c94b0',1,'RegGenerator']]],
  ['registrconfig',['RegistrConfig',['../class_registr_config.html#a9b9fed35d14dfed2223389df4ea1d2f8',1,'RegistrConfig::RegistrConfig(QObject *parent=nullptr)'],['../class_registr_config.html#aa8266801862bcb19391019e5997335b5',1,'RegistrConfig::RegistrConfig(int registrNumber, ValueType valueType, QString TrueValueFunction, QString DinamicErrorFunction, double zeroShift, RandomDistributionType randomDistributionType, QVector&lt; double &gt; randomDistributionParams)'],['../class_registr_config.html#a72d544ec8d5b56bdbb2024924496e2fe',1,'RegistrConfig::RegistrConfig(const RegistrConfig &amp;o)']]],
  ['reset',['reset',['../class_pulse_controller.html#a0112f4a30c50e9254e8e264f5b1ba865',1,'PulseController']]]
];
