var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvwxz~",
  1: "bcfijmoprsvw",
  2: "u",
  3: "bcefijmoprsvw",
  4: "abcefgijlmnoprstuvw~",
  5: "acdghijmnoprstvwxz",
  6: "egps",
  7: "rsv",
  8: "efijlmnrstuvz",
  9: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Пространства имен",
  3: "Файлы",
  4: "Функции",
  5: "Переменные",
  6: "Определения типов",
  7: "Перечисления",
  8: "Элементы перечислений",
  9: "Макросы"
};

