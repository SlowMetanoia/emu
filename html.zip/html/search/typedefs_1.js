var searchData=
[
  ['genfunc',['genfunc',['../series_8h.html#af9f3bd42d39ff918f5ad19b5d5df4dac',1,'series.h']]]
];
