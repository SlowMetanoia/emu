var searchData=
[
  ['journalwirter',['journalWirter',['../class_journal_writer.html#a45bf8cd477467fdc28964126438a071a',1,'JournalWriter']]],
  ['journalwriter',['journalWriter',['../class_out_manager.html#a06df9af523b794582b5acb28906c811c',1,'OutManager']]]
];
