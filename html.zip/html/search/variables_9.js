var searchData=
[
  ['outputfile',['outputFile',['../class_journal_writer.html#a4e2e6d2d0208bd4d168004cd9b403fd4',1,'JournalWriter']]]
];
