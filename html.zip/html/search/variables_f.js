var searchData=
[
  ['windowmanager',['windowManager',['../class_window_manager.html#aeac5c58442c8ec0caff4bdb96660d2d6',1,'WindowManager']]],
  ['writer',['writer',['../class_socket_writer.html#adb08a0fb11026b6321905d53eaf3a4cb',1,'SocketWriter']]]
];
